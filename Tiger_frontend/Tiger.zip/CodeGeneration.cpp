#include <map>
#include <vector>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <string>
#include "scope.cpp"
#include "CodeGeneration.h"
